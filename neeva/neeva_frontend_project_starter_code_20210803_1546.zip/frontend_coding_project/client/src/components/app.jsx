import * as React from 'react';
import "./app.css";

// This is a placeholder. Feel free to edit or remove this code :)
export function App() {
  return (
    <div className="app">
      <header className="appHeader">
        <h1>Digital flipbook player</h1>
      </header>
      <main>
        <p>Good luck!</p>
      </main>
    </div>
  );
}
